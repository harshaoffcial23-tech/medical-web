import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ProductCard } from "@/components/product-card";
import { z } from "zod";

export const Route = createFileRoute("/search")({
  component: SearchPage,
  validateSearch: (s) => z.object({ q: z.string().optional().default("") }).parse(s),
});

function SearchPage() {
  const { q } = Route.useSearch();
  const { data } = useQuery({
    queryKey: ["search", q],
    queryFn: async () => {
      if (!q) return [];
      const { data } = await supabase
        .from("products")
        .select("*, category:categories(name, slug)")
        .ilike("name", `%${q}%`);
      return data ?? [];
    },
  });
  return (
    <div className="mx-auto max-w-7xl px-4 py-12">
      <h1 className="font-display text-3xl font-bold">Search results for "{q}"</h1>
      <p className="text-muted-foreground mt-1">{data?.length ?? 0} matches</p>
      <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {data?.map((p, i) => <ProductCard key={p.id} product={p as never} index={i} />)}
      </div>
    </div>
  );
}
