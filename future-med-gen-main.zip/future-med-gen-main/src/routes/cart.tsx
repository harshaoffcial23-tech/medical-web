import { createFileRoute, Link } from "@tanstack/react-router";
import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";

export const Route = createFileRoute("/cart")({
  component: CartPage,
});

function CartPage() {
  const { items, subtotal, discount, total, updateQuantity, removeItem } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] grid place-items-center px-4">
        <div className="text-center">
          <div className="mx-auto size-20 rounded-full glass-card grid place-items-center mb-6">
            <ShoppingBag className="size-8 text-muted-foreground" />
          </div>
          <h1 className="font-display text-2xl font-bold">Your cart is empty</h1>
          <p className="text-muted-foreground mt-2">Add some medicines to get started.</p>
          <Button asChild className="mt-6 rounded-full gradient-primary text-primary-foreground border-0">
            <Link to="/products">Shop now</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="font-display text-3xl font-bold mb-8">Your cart</h1>
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => {
            const final = Number(item.product.mrp) * (1 - Number(item.product.discount_percent) / 100);
            return (
              <div key={item.id} className="flex gap-4 p-4 rounded-2xl glass-card">
                <div className="size-20 rounded-xl bg-gradient-to-br from-accent/30 to-secondary/40 grid place-items-center shrink-0">
                  {item.product.image_url ? (
                    <img src={item.product.image_url} alt={item.product.name} className="size-full object-cover rounded-xl" />
                  ) : (
                    <span className="text-2xl font-display font-bold text-primary/30">{item.product.name.charAt(0)}</span>
                  )}
                </div>
                <div className="flex-1">
                  <Link to="/products/$slug" params={{ slug: item.product.slug }} className="font-semibold hover:text-primary">
                    {item.product.name}
                  </Link>
                  <p className="text-sm font-bold mt-1">₹{final.toFixed(0)} <span className="text-xs text-muted-foreground line-through font-normal">₹{Number(item.product.mrp).toFixed(0)}</span></p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)}><Trash2 className="size-4" /></Button>
                  <div className="flex items-center rounded-lg ring-1 ring-border">
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => updateQuantity(item.id, item.quantity - 1)}><Minus className="size-3" /></Button>
                    <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                    <Button variant="ghost" size="icon" className="size-8" onClick={() => updateQuantity(item.id, item.quantity + 1)}><Plus className="size-3" /></Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <aside className="rounded-2xl glass-card p-6 h-fit space-y-3">
          <h2 className="font-display font-semibold text-lg">Order summary</h2>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>₹{subtotal.toFixed(0)}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Discount</span><span className="text-mint">-₹{discount.toFixed(0)}</span></div>
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Shipping</span><span>Free</span></div>
          <div className="border-t pt-3 flex justify-between font-display font-bold text-lg"><span>Total</span><span>₹{total.toFixed(0)}</span></div>
          <Button asChild size="lg" className="w-full mt-4 rounded-xl gradient-primary text-primary-foreground border-0">
            <Link to="/checkout">Proceed to checkout</Link>
          </Button>
        </aside>
      </div>
    </div>
  );
}
