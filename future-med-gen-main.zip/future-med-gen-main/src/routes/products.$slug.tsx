import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { useState } from "react";
import { Minus, Plus, ShieldCheck, Truck, RefreshCw } from "lucide-react";

export const Route = createFileRoute("/products/$slug")({
  component: ProductDetailPage,
});

function ProductDetailPage() {
  const { slug } = useParams({ from: "/products/$slug" });
  const { addItem } = useCart();
  const [qty, setQty] = useState(1);

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", slug],
    queryFn: async () => {
      const { data } = await supabase
        .from("products")
        .select("*, category:categories(name, slug)")
        .eq("slug", slug)
        .single();
      return data;
    },
  });

  if (isLoading) return <div className="p-12 text-center text-muted-foreground">Loading…</div>;
  if (!product) return <div className="p-12 text-center">Not found</div>;

  const finalPrice = Number(product.mrp) * (1 - Number(product.discount_percent) / 100);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <nav className="text-sm text-muted-foreground mb-6">
        <Link to="/" className="hover:text-primary">Home</Link> /{" "}
        <Link to="/products" className="hover:text-primary">Medicines</Link> / <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="aspect-square rounded-3xl glass-card overflow-hidden grid place-items-center">
          {product.image_url ? (
            <img src={product.image_url} alt={product.name} className="size-full object-cover" />
          ) : (
            <div className="text-9xl font-display font-bold text-primary/20">{product.name.charAt(0)}</div>
          )}
        </div>

        <div>
          {product.category && (
            <Link to="/categories/$slug" params={{ slug: product.category.slug }} className="text-xs font-bold uppercase tracking-widest text-primary">
              {product.category.name}
            </Link>
          )}
          <h1 className="mt-2 font-display text-4xl font-bold tracking-tight">{product.name}</h1>
          {product.brand && <p className="text-muted-foreground mt-1">{product.brand}</p>}

          <div className="mt-6 flex items-baseline gap-3">
            <span className="text-4xl font-display font-bold">₹{finalPrice.toFixed(0)}</span>
            {product.discount_percent > 0 && (
              <>
                <span className="text-lg text-muted-foreground line-through">₹{Number(product.mrp).toFixed(0)}</span>
                <span className="text-sm font-bold text-mint">{Number(product.discount_percent).toFixed(0)}% OFF</span>
              </>
            )}
          </div>

          <p className="mt-6 text-muted-foreground">{product.description}</p>

          {product.usage_info && (
            <div className="mt-6">
              <h3 className="font-display font-semibold">Usage</h3>
              <p className="text-sm text-muted-foreground mt-1">{product.usage_info}</p>
            </div>
          )}
          {product.ingredients && (
            <div className="mt-4">
              <h3 className="font-display font-semibold">Ingredients</h3>
              <p className="text-sm text-muted-foreground mt-1">{product.ingredients}</p>
            </div>
          )}

          <div className="mt-8 flex items-center gap-4">
            <div className="flex items-center rounded-xl ring-1 ring-border">
              <Button variant="ghost" size="icon" onClick={() => setQty(Math.max(1, qty - 1))}><Minus className="size-4" /></Button>
              <span className="w-10 text-center font-semibold">{qty}</span>
              <Button variant="ghost" size="icon" onClick={() => setQty(qty + 1)}><Plus className="size-4" /></Button>
            </div>
            <Button
              size="lg"
              onClick={() => addItem(product.id, qty)}
              disabled={product.stock === 0}
              className="flex-1 rounded-xl gradient-primary text-primary-foreground border-0 shadow-elevated"
            >
              {product.stock === 0 ? "Out of stock" : "Add to cart"}
            </Button>
          </div>

          <div className="mt-8 grid grid-cols-3 gap-3 text-xs">
            <div className="flex items-center gap-2 p-3 rounded-xl glass-card"><ShieldCheck className="size-4 text-mint" /> Verified</div>
            <div className="flex items-center gap-2 p-3 rounded-xl glass-card"><Truck className="size-4 text-mint" /> Fast delivery</div>
            <div className="flex items-center gap-2 p-3 rounded-xl glass-card"><RefreshCw className="size-4 text-mint" /> Easy returns</div>
          </div>
        </div>
      </div>
    </div>
  );
}
